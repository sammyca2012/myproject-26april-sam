_release = '29'
_version = '2.0-' + _release

def get_release():
    return _release

def get_version():
    return _version
